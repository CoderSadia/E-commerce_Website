<?php

if (!defined('WPVIVID_PLUGIN_DIR')){
    die;
}
return array(
    'task_id' => '',
    'data' => array(),
    'state' => WPVIVID_RESTORE_INIT,
    'error' => '',
    'error_task' => ''
);