
 ### v1.3.2 - 2019-04-18 
 **Changes:** 
 * fix: PHP notice in themeisle-content-forms
 
 ### v1.3.1 - 2019-04-17 
 **Changes:** 
 * Fix issues with newsletter form
 
 ### v1.3.0 - 2019-03-08 
 **Changes:** 
 * Tested with latest WordPress version, 5.1
* Remove mention of Pro add-on, discontinue recommendation of the Premium features
 
 ### v1.2.9 - 2018-12-12 
 **Changes:** 
 * fix templates directory importing
 
 ### v1.2.8 - 2018-12-10 
 **Changes:** 
 * Tested with WP 5.0
 
 ### v1.2.7 - 2018-11-27 
 **Changes:** 
 * Update recommended theme link
 
 ### v1.2.6 - 2018-11-12 
 **Changes:** 
 * Fix issue with elementor content forms php notice
* Security fixes
* Performance enhancements
* Add notice to awesome Neve theme
 
 ### v1.2.5 - 2018-07-26 
 **Changes:** 
 * Fix bug for Elementor content forms.
 
 ### v1.2.4 - 2018-07-23 
 **Changes:** 
 * Add new controls for Elementor content forms.
 
 ### v1.2.3 - 2018-07-11 
 **Changes:** 
 * Version bump.
 
 ### v1.2.2 - 2018-07-11 
 **Changes:** 
 * Added styling options for elementor form widgets
 
 ### v1.2.1 - 2018-07-06 
 **Changes:** 
 * Fixes post grid pagination issue
* Fixes post grid colors not applying correctly
* Fixes Templates directory import issue
* Fixes content forms placeholder not used
* New templates in the templates directory
 
 ### v1.2.0 - 2018-03-29 
 **Changes:** 
 * Adds support for the premium version.
* Adds automatic page templates synchronization.
* Adds support for future extra-widgets and add-ons.
 
 ### v1.1.7 - 2018-03-29 
 **Changes:** 
 * Development
 
 ### v1.1.6 - 2018-03-29 
 **Changes:** 
 * Rebranded plugin to Sizzify
 
 ### v1.1.5 - 2018-02-08 
 **Changes:** 
 * Added Template Directory [under Pages > Template Directory]
* Added new Content Forms widgets
* A more modular structure
 
 ### v1.1.4 - 2017-12-18 
 **Changes:** 
 * Fixed Pricing Table Widget button link issue
* Fixed Post Grid Widget notice.
* Fixed Services Widget content align.
 
 ### v1.1.3 - 2017-11-17 
 **Changes:** 
 * Fixed javascript error on front end.
 
 ### v1.1.2 - 2017-11-16 
 **Changes:** 
 * Added three new Elementor native widgets.
* Tested up to 4.9
 
 ### v1.1.1 - 2017-10-11 
 **Changes:** 
 * Updated title and description
* Updated tested up to version 4.8
 
 ### v1.1.0 - 2017-09-29 
 **Changes:** 
 * Travis trigger.
* Added Themeisle SDK.
* Added Continuous Integration.
* Changed contributors.
 
