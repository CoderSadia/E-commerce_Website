<?php
/**
 * Template Library Header Tabs
 */
?>
<label>
	<input type="radio" value="{{ slug }}" name="premium-template-modal-header-tab">
	<span>{{ title }}</span>
</label>