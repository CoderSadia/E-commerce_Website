<?php
/**
 * Templates Back to Library Button
 */
?>
<button type="button" class="premium-template-modal-back">
	<i class="dashicons dashicons-arrow-left-alt2"></i>
	<?php echo __( 'Back to Library', 'premium-addons-for-elementor' ); ?>
</button>